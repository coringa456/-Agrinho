
// Variáveis para armazenar o cesto e as frutas
let cesto;
let frutas = [];
let pontos = 0;

function setup() {
  createCanvas(800, 600);
  cesto = new Cesto(width / 2, height - 50);
  
  // Cria frutas em intervalos aleatórios
  setInterval(() => {
    frutas.push(new Fruta(random(width), 0));
  }, 1000);
}

function draw() {
  background(220);
  
  // Move e mostra o cesto
  cesto.mostra();
  cesto.move();
  
  // Move e mostra as frutas
  for (let i = frutas.length - 1; i >= 0; i--) {
    frutas[i].mostra();
    frutas[i].move();
    
    // Verifica se a fruta foi pega
    if (frutas[i].y + frutas[i].h > cesto.y && frutas[i].x > cesto.x && frutas[i].x < cesto.x + cesto.w) {
      pontos++;
      frutas.splice(i, 1);
    }
    
    // Remove a fruta se ela sair da tela
    if (frutas[i] && frutas[i].y > height) {
      frutas.splice(i, 1);
    }
  }
  
  // Mostra os pontos
  fill(0);
  textSize(24);
  text(`Pontos: ${pontos}`, 10, 30);
}

// Classe Cesto
class Cesto {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.w = 100;
    this.h = 50;
    this.vel = 5;
  }
  
  mostra() {
    fill(139, 69, 19);
    rect(this.x, this.y, this.w, this.h);
  }
  
  move() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= this.vel;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.w) {
      this.x += this.vel;
    }
  }
}

// Classe Fruta
class Fruta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.w = 30;
    this.h = 30;
    this.vel = random(2, 5);
  }
  
  mostra() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.w, this.h);
  }
  
  move() {
    this.y += this.vel;
  }
}